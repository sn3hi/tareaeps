
package com.mycompany.ejemplolinkedhashmap;

/**
 *
 * @author snehider y tomas
 */
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class EjemploLinkedHashMap {

    public static void main(String[] args) {
        
        //crear un linkedmashmap con las peliculas en desorden
        LinkedHashMap <Integer, String>pelicula = new  LinkedHashMap<>();
        
        //agrgar las peliculas
        pelicula.put(2004,"Los increibles");
        pelicula.put(1988,"Akira");
        pelicula.put(1999,"El gigante de hierro");
        pelicula.put(2014, "Grandes heroes");
        pelicula.put(2018,"Spider-Man: un nuevo universo");
        pelicula.put(2009,"Up");
        pelicula.put(1993,"La lista de Schindles");
        pelicula.put(2011,"Kung Fu panda 2");
        pelicula.put(2019,"Klaus");
        pelicula.put(2002,"8 Mile: Calle de las ilusiones");
        pelicula.put(2011,"gigantes de acero");
        pelicula.put( 2007,"ratatouille");
        pelicula.put(1984, "Amadeus");
        
        
        //pasar a array para poder ordenarlo
        List<Map.Entry<Integer, String>> listaEntradas = new ArrayList<>(pelicula.entrySet());

        // Ordenar la lista de fechas utilizando un comparador 
        Collections.sort(listaEntradas, (Map.Entry<Integer, String> entrada1, Map.Entry<Integer, String> entrada2) -> entrada1.getKey().compareTo(entrada2.getKey()));

        // Crear un nuevo LinkedHashMap ordenado
        LinkedHashMap<Integer, String> linkedHashMapOrdenado = new LinkedHashMap<>();
        Iterator<Map.Entry<Integer, String>> iterator = listaEntradas.iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, String> entrada = iterator.next();
            linkedHashMapOrdenado.put(entrada.getKey(), entrada.getValue());
        }

        // Imprimir el LinkedHashMap ordenado
        System.out.println("peliculas ordenadas por fecha:");
        for (Map.Entry<Integer, String> entrada : linkedHashMapOrdenado.entrySet()) {
            System.out.println(entrada.getKey() + ": " + entrada.getValue());
        }
        
        
        
        //pasar a array para poder ordenarlo
        List<Map.Entry<Integer, String>> listaEntradas2 = new ArrayList<>(pelicula.entrySet());
        
        // Ordenar la lista de fechas utilizando un comparador 
        Collections.sort(listaEntradas2, (Map.Entry<Integer, String> entrada1, Map.Entry<Integer, String> entrada2) -> entrada1.getValue().compareTo(entrada2.getValue()));

        // Crear un nuevo LinkedHashMap ordenado
        LinkedHashMap<Integer, String> linkedHashMapOrdenado2 = new LinkedHashMap<>();
        Iterator<Map.Entry<Integer, String>> iterator2 = listaEntradas2.iterator();
        while (iterator2.hasNext()) {
            Map.Entry<Integer, String> entrada = iterator2.next();
            linkedHashMapOrdenado2.put(entrada.getKey(), entrada.getValue());
        }

        // Imprimir el LinkedHashMap ordenado
        System.out.println("peliculas ordenadas alfabeticamente:");
        for (Map.Entry<Integer, String> entrada : linkedHashMapOrdenado2.entrySet()) {
            System.out.println(entrada.getKey() + ": " + entrada.getValue());
        }
    }

        
    
}
