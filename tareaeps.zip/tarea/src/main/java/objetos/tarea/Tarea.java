
package objetos.tarea;

import java.util.Scanner;


public class Tarea {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar nombre y edad
        System.out.print("Ingrese el nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Ingrese la edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea después del entero

        pair<Integer, String> person = new pair<>(edad, nombre);
        
        // Solicitar EPS y fecha de nacimiento
        System.out.print("Ingrese la EPS: ");
        String eps = scanner.nextLine();
        
        System.out.print("Ingrese la fecha de nacimiento (dd/mm/aaaa): ");
        String fechaNacimiento = scanner.nextLine();

        pair<String, String> epsAndBirthDate = new pair<>(eps, fechaNacimiento);
        System.out.println("Nombre y edad: " + person);
        System.out.println("EPS y fecha de nacimiento: " + epsAndBirthDate);
        
        // Cerrar el escáner
        scanner.close();
    }
}
